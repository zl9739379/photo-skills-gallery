---
name: photo-space-skills-gallery
description: Process a single photo through every skill documented in the WorkBuddy library "照片" (photo) space using the local gpt_image_2.py script, output each skill's result as a standalone image (no stitching with the source photo), and generate an HTML gallery page listing skill names, GitHub origins, and effect descriptions.
agent_created: true
---

# Photo Space Skills Gallery

## Overview

This skill turns one source photograph into a complete gallery by running every skill found in the WorkBuddy library's "照片" (photo) space. Each skill produces one standalone PNG. Skills that normally stitch the source image and the processed result together are intentionally output as the processed result only. The final deliverable is a self-contained HTML page that showcases every result with skill metadata and GitHub links.

## When to Use

Use this skill when the user asks something like:
- "用资料库照片空间里的所有技能处理这张照片"
- "把照片空间的技能都跑一遍"
- "生成一个网页展示所有照片技能的处理结果"
- Any request to apply the full set of WorkBuddy photo-space skills to one or more images and present them in a gallery.

## Required Environment

- Local script: `C:/Users/ilost/.workbuddy/scripts/gpt_image_2.py` (aifast gateway, `gpt-image-2` model, 1024×1536 default).
- Managed Python: `C:/Users/ilost/.workbuddy/binaries/python/versions/3.13.12/python.exe`.
- Internet access to `aifast.site` for image generation.
- WorkBuddy library access (obtain open platform token via `connect_open_platform` with `skill_id: library`).

## Workflow

1. **Locate the source image(s)**
   - Default workspace: `C:/Users/ilost/Desktop/照片/list/`.
   - Accept explicit paths from the user if provided.

2. **Discover photo-space skills**
   - Connect to the WorkBuddy Open Platform and list user library spaces.
   - Find the space whose title contains "照片" (photo).
   - List root nodes and identify skill summary documents.
   - Read each document (via `doc/get_doc_reviews.py`) and cache locally.
   - Extract from each document: skill display name, GitHub origin, default stitching behavior, and visual effect.

3. **Build the skill manifest**
   - For each skill, decide:
     - `mode`: `gen` (text-to-image) or `edit` (image-to-image).
     - `size`: default `1024x1536` for vertical poster/zine outputs.
     - `prompt`: an English prompt that translates the skill's style into a concrete generation instruction based on the source photo's content.
   - Mark skills that normally stitch with the source image; plan to output only the processed part.

4. **Generate images**
   - Run `gpt_image_2.py` once per skill.
   - Save outputs under `<workspace>/results/NN_skill-name.png`.
   - Save each prompt under `<workspace>/results/prompts/NN_skill-name.txt` for traceability.
   - Verify each output file exists and is non-empty.

5. **Quality Gate**
   - Open each generated image.
   - Confirm the visual style matches the skill description.
   - Confirm no source photo is embedded inside a stitched composite (the user asked for standalone results).

6. **Build the HTML gallery**
   - Create `<workspace>/photo_skills_gallery.html`.
   - Include:
     - Hero thumbnail of the source photo with caption.
     - One card per skill: result image, skill name, GitHub link, Chinese effect description, and a badge indicating whether the source image was originally stitched.
     - Summary table: # / skill / GitHub / default stitching / standalone output effect.
   - Use system fonts only, light theme, no external dependencies.

7. **Deliver and record**
   - Present the HTML and result images with `present_files`.
   - Append a note to the workspace daily memory log.

## Known Photo-Space Skills (as of 2026-08-23)

| # | Skill | GitHub Origin | Default Stitching | Standalone Output |
|---|---|---|---|---|
| 01 | photo-abstract-editorial | ZzzLc0405/photo-abstract-editorial | Yes (source + abstract panel) | Ivory editorial abstract panel |
| 02 | Compose Photo Memory Archive | sbj61188-lab/compose-photo-memory-archive | Yes (source + watercolor memory field) | Watercolor memory field |
| 03 | Scene Distillation Zine v1.3 | Zeejay0/gathered-scenes-zine-skill | No | Risograph-style illustration poster |
| 04 | Gathered Scenes Zine v1.3 | Zeejay0/gathered-scenes-zine-skill | Yes (source anchor + torn-paper collage) | Torn-paper collage illustration |
| 05 | gc-minimal-zine-poster | LiamGvchi/gc-minimal-zine-poster | No | Minimal zine poster |
| 06 | 8bit-pixel-fusion | TwentyfiveBTea/8bit-pixel-art | No | 8-bit pixel abstraction |
| 07 | Photo Ink Echo | zhouaria28-cloud/photo-ink-echo | Yes (source + ink-wash motif) | Chinese ink-wash motif panel |

> Always re-read the library documents at runtime; the set of skills may grow or change.

## Bundled Resources

### `scripts/run_photo_skills.py`

A reference orchestrator that:
- Defines the 7 known skills with prompts, modes, sizes, and GitHub origins.
- Runs `gpt_image_2.py` sequentially for each skill.
- Saves prompts and outputs to `results/` and `results/prompts/`.
- Prints a generation report.

Copy and adapt this script into the target workspace when executing. It is a template, not a globally runnable command, because prompts should be derived from the actual source photo each time.

## Important Rules

- **Never stitch the source image into the final output** unless the user explicitly asks for the original composite layout.
- Use `edit` mode only when the skill specifically requires deriving from the source photo (e.g., `Compose Photo Memory Archive`). Otherwise prefer `gen` to keep the output purely abstract/interpretive.
- Keep all generation within the local `gpt_image_2.py` script; do not use remote `ImageGen` tools for this workflow.
- All GitHub links must be the exact repositories referenced in the library documents.
